 
 --1.3 Q1
 create table manju.customers_930(customerid int unique not null,customername varchar(20) not null,
              address1 varchar(30),address2 varchar(30),contactnumber varchar(10) not null,
			  postalcode varchar(10));

--1.3 Q2
create table manju.employees_930(employeeid int not null primary key,name nvarchar(255) null);


--1.3 Q2.0
create table manju.contractors_930(contractorid int not null primary key,name nvarchar(255) null);

--1.3 Q3
use Training;

create table dbo.TestRethrow_930(id int primary key);

create DEFAULT [manju] North America as 'NA'; 

--1.3 Q4
 alter table manju.customers_930 add customer_region Region;

 --1.3 Q5
 alter table manju.customers_930 add Gender char(10);

 --1.3 Q6
 alter table manju.customers_930 add constraint ck_gender check(Gender in ('M','F','T'));

 --1.3 Q7
 create table manju.orders_930(orderid int not null check(orderid>=1000),customerid int not null,orderdate datetime,
              orderstate char(1) check(orderstate in('P','C')));

--1.3 Q8
alter table manju.orders_930 add constraint fk_custorders foreign key (customerid) references manju.customers_930(customerid);