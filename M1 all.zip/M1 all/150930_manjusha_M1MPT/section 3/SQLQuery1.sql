use [16MayCHN]
--1
create table manju.Departments
(Department_Code integer primary key,
Department_Name varchar(15));

insert into manju.Departments values(10,'Admin');
insert into manju.Departments values(20,'HR');
insert into manju.Departments values(30,'Finance');
insert into manju.Departments values(40,'Sales');
insert into manju.Departments values(50,'Marketing');

create table manju.Employees
(Employee_Code integer primary key,
Employee_Name varchar(20),
Date_Of_Joining date,
Salary integer,
Grade char(2),
Department_Code integer constraint dept_code foreign key references manju.Departments(Department_Code));

insert into manju.Employees values(101,'Preetam','10-JAN-2010',18000,'A',20);
insert into manju.Employees values(102,'Aakash','10-Nov-2005',48000,'C',10);
insert into manju.Employees values(103,'Kishore','19-DEC-2011',42000,'C',40);
insert into manju.Employees values(104,'Reena','23-JUN-2006',33000,'B',20);
insert into manju.Employees values(105,'Kailash','10-FEB-2004',36000,'C',30);

--2a
select Employee_Code,Employee_Name,Salary from manju.Employees where Employee_Name like 'K%';
--2b
select Employee_Code from manju.Employees order by Grade;
--2d
select Employee_Name from manju.Employees where Department_Code IN(10,20,30); 