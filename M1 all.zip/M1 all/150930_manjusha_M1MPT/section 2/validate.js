function validate(){
	//var name = document.frmRegister.txtName.value;
	//alert("All data for "+fname+" entered successfully.");
	var etitle= document.frmRegister.title.value;
	var ef_name= document.frmRegister.fname.value;
	var el_name = document.frmRegister.lname.value;
	var esalery= document.frmRegister.salery.value;
	var eaddress= document.frmRegister.address.value;
	var win = window.open();
	var newDocument = win.document;
	newDocument.write("<h1>Employee Details</h2>");
	newDocument.write("<h1/>Title :</h1>"+etitle);
	newDocument.write("<h1/>FirstName :</h1>"+ef_name);
	newDocument.write("<h1/>LastName :</h1>"+el_name);
	newDocument.write("<h1/>Gross Salary :</h1>"+esalery);
	newDocument.write("<h1/>Address :</h1>"+eaddress);
}